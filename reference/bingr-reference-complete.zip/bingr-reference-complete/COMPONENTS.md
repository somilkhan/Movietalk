# COMPONENTS

Use dom/, computed-css/ and bounding-boxes/ for rendered component evidence.
