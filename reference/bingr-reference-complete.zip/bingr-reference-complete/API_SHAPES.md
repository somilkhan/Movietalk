# API SHAPES

Private/authenticated API bodies are intentionally not collected. Use RabbitRip's own backend/data layer for implementation.
