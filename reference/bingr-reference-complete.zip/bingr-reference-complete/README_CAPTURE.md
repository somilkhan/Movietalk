# Capture complete

Routes discovered: 23

Viewports:
- 1440x900
- 1920x1080
- 390x844
- 412x915

Generated folders:
- screenshots/
- dom/
- computed-css/
- bounding-boxes/
- assets/
- routes/
- interactions/
- responsive/
- accessibility/
- styles/
- errors/