# ASSETS

Rendered asset references and image metadata are under assets/.
